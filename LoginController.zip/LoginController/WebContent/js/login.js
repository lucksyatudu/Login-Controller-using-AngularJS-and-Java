var App=angular.module('logInApp',[]);

/*	
App.config(['$routeProvider',function($routeProvider){
		$routeProvider
		.when('/',{
		loginUrl:'/index.html',
		controller:'logInController'
		})
	}]);
*/		
	

App.controller('logInController',function($scope,$http){
	$scope.message="Message";
	$scope.logIn=function(username,password)
	{
		var urlIs="http://localhost:8080/LoginController/demo/login/validate/"+$scope.username+"/"+$scope.password;
		$http.get(urlIs)
			.success(function(data){
				if(data===1)
					$scope.message="Welcome "+username;
				else
					$scope.message="Error";
			})
			.error(function(status){
				$scope.message="Error 400";
			})
	}
});